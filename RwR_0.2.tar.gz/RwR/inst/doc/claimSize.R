## ----defaultOptions, echo=FALSE, results="hide", message=FALSE, warning=FALSE, cache=FALSE----
### This chuck sets all the options used by knitr.
library(knitr)
opts_chunk$set(background=c(0.97, 0.97, 0.97), tidy=FALSE, cache=TRUE, dev='pdf', size='footnotesize', fig.align='center', out.width='\\linewidth')
opts_template$set(widefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(rightwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(leftwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(marginfigure = list(fig.height=4, fig.width=4, fig.env='marginfigure'))
opts_template$set(figure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(rightfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(leftfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
options(width = 65, show.signif.stars = FALSE)
hook_output <- knit_hooks$get("output")
knit_hooks$set(output = function(x, options) {
  lines <- options$output.lines
  if (is.null(lines)) {
    hook_output(x, options)  # pass to default hook
  }
  else {
    x <- unlist(stringr::str_split(x, "\n"))
    xx <- character(length(x))
    lines <- seq_along(x)[lines]
    gap <- 0
    j <- k <- 1
    browser()
    for(i in seq_along(x)) {
      if(k <= length(lines) && i == lines[k]) {
        xx[j] <- x[i]
        j <- j + 1
        k <- k + 1
        gap <- 0
      } else if(gap == 0) {
        xx[j] <- "..."
        j <- j + 1
        gap <- 1
      }
    }
    # paste these lines together
    x <- paste(xx[xx != ""], collapse = "\n")
    hook_output(x, options)
  }
})

## ----packages, cache=FALSE, message=FALSE, results="hide", warning=FALSE, echo=FALSE----
library(ggplot2)   ## Grammar of graphics
library(reshape2)  ## Reshaping data frames
library(lattice)   ## More graphics
library(hexbin)    ## and more graphics
library(gridExtra) ## ... and more graphics
library(xtable)    ## LaTeX formatting of tables
library(splines)   ## Splines -- surprise :-)
library(survival)  ## Survival analysis
library(grid)      ## For 'unit'
library(lpSolve)   ## Linear programming

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Introcase/figure/', cache.path='Introcase/cache/')

## ----readingClaims---------------------------------------------
claims <- read.table(
  "http://www.math.ku.dk/~richard/regression/data/claims.txt",
  sep = ";", 
  colClasses = c("character", "numeric", "numeric", "factor"))

## ----head, dependson="readingClaims"---------------------------
head(claims)

## ----claimsScatter, dependson="readingClaims", opts.label='leftfigure', fig.cap="Scatter plot of claim size against insurance sum. Note the log-log axes."----
p0 <- qplot(sum, claims, data = claims, alpha = I(0.2)) + 
  scale_x_log10("Insurance sum (DKK)", breaks = 10^c(6, 7, 8), 
                labels = c("1M", "10M", "100M")) +
  scale_y_log10("Claim size (DKK)", breaks = 10^c(2, 4, 6, 8), 
                labels = c("100", "10K", "1M", "100M"))
p <- p0 + geom_smooth(method = "lm", size = 2, se = FALSE) 
p

## ----claimsScatterStrat, dependson=c("readingClaims", "claimsScatter"), fig.cap="Scatter plots of claim size against insurance sum stratified according to trade group. A regression line is added to the plots for each group.", opts.label='rightwidefigure'----
p + facet_wrap(~ grp, ncol = 4)

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Introcase/figure/', cache.path='Introcase/cache/')

## ----claimsLm, dependson="readingClaims"-----------------------
claimsLm <- lm(log(claims) ~ log(sum), data = claims)
coefficients(claimsLm)

## --------------------------------------------------------------
model.matrix(claimsLm)[781:784, ]

## ----claimsLmAdd, dependson="readingClaims"--------------------
claimsLmAdd <- lm(log(claims) ~ log(sum) + grp, data = claims)
coefficients(claimsLmAdd)
model.matrix(claimsLmAdd)[781:784, ]

## ----claimsLmAdd2, dependson="readingClaims"-------------------
claimsLmAdd <- lm(log(claims) ~ log(sum) + grp, data = claims,
                  contrasts = list(grp = "contr.sum"))
coefficients(claimsLmAdd)
model.matrix(claimsLmAdd)[781:784, ]

## ----claimsLmInt, dependson="readingClaims"--------------------
claimsLmInt <- lm(log(claims) ~ log(sum) * grp, data = claims)
coefficients(claimsLmInt)
model.matrix(claimsLmInt)[781:784, ]

## ----claimsDiag, dependson="claimsLm", fig.env='figure', fig.width=9, fig.height=3, fig.cap="Diagnostic plots based on residuals for the regression model conditioning on insurance sum only. The residual plot (left) and the histogram (middle) use the raw residuals. The qq-plot (right) uses standardized residuals."----
claimsDiag <- fortify(claimsLm) ## Residuals etc.
grid.arrange(
  qplot(.fitted, .resid, data = claimsDiag, alpha = I(0.2)) +
    geom_smooth(),
  qplot(.resid, data = claimsDiag, bins = I(40)),
  qplot(sample = .stdresid, data = claimsDiag, geom = "qq") +
    geom_abline(),
  ncol = 3
)

## ----claimsDiagInt, dependson="claimsLmInt", fig.env='figure', fig.width=9, fig.height=3, fig.cap="Diagnostic plots based on residuals for the regression model with an interaction of trade group and insurance sum. The residual plot (left) and the histogram (middle) use the raw residuals. The qq-plot (right) uses standardized residuals.", echo=FALSE----
claimsDiagInt <- fortify(claimsLmInt) ## Residuals etc.
grid.arrange(
  qplot(.fitted, .resid, data = claimsDiagInt, alpha = I(0.2)) +
    geom_smooth(),
  qplot(.resid, data = claimsDiagInt, bins = I(40)),
  qplot(sample = .stdresid, data = claimsDiagInt, geom = "qq") +
    geom_abline(),
  ncol = 3
)

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Introcase/figure/', cache.path='Introcase/cache/')

## ----sumClaims, dependson="claimsLm", output.lines=-(1:8)------
summary(claimsLm)

## --------------------------------------------------------------
cor(log(claims$claims), log(claims$sum))^2

## ----sumClaimsAdd, dependson="claimsLmAdd", output.lines=-(1:8)----
summary(claimsLmAdd)

## ----sumClaimsInt, dependson="claimsLmInt", output.lines=-(1:8)----
summary(claimsLmInt)

## ----claimsTest, dependson=c("claimsLm", "claimsLmAdd", "claimsLmInt")----
anova(claimsLm, claimsLmAdd, claimsLmInt)

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Introcase/figure/', cache.path='Introcase/cache/')

## ----poly, opts.label='marginfigure', fig.cap='A basis of orthogonal polynomials.', echo=FALSE, fig.pos='0.2cm'----
x <- seq(11, 21, 0.05)
pol <- as.data.frame(cbind(x, poly(x, degree = 5)))
mPol <- melt(pol, id.vars = "x")
p <- ggplot(NULL, aes(x, value, colour = variable)) +
  scale_color_discrete(guide = "none") + xlab("") + ylab("")
p + geom_line(data = mPol, size = 1)

## ----bSpline, dependson='poly', opts.label='marginfigure', echo=FALSE, fig.cap='A basis of cubic $B$-splines computed using the \\texttt{bs} function with two internal knots at 14 and 18 in addition to two boundary knots at 11 and 21.', fig.pos='1cm'----
bSpline <- as.data.frame(cbind(x, bs(x, knots = c(14, 18))))
mBSpline <- melt(bSpline, id.vars = "x")
p + geom_line(data = mBSpline, size = 1) +
  geom_rug(aes(x = c(11, 14, 18, 21), y = NULL, color = NULL), size = 2)

## ----nSpline, dependson='poly', opts.label='marginfigure', echo = FALSE, fig.cap='A $B$-spline basis for natural cubic splines computed using the \\texttt{ns} function with internal knots at 13, 15, 17 and 19 in addition to the two boundary knots at 11 and 21.'----
nSpline <- as.data.frame(cbind(x, ns(x, knots = c(13, 15, 17, 19))))
mNSpline <- melt(nSpline, id.vars = "x")
p + geom_line(data = mNSpline, size = 1) +
  geom_rug(aes(x = c(11, 13, 15, 17, 19, 21), y = NULL, color = NULL), size = 2)

## ----claimsSpline, dependson="readingClaims"-------------------
claimsLmSplineAdd <- lm(
  log(claims) ~ ns(log(sum), knots = c(13, 15, 17, 19)) + grp,
  data = claims)
claimsLmSplineInt <- lm(
  log(claims) ~ ns(log(sum), knots = c(13, 15, 17, 19)) * grp,
  data = claims)

## ----claimsSplineSum1, dependson="claimsSpline", output.lines=32:35----
summary(claimsLmSplineAdd)

## ----claimsSplineSum2, dependson="claimsSpline", output.lines=87:90----
summary(claimsLmSplineInt)

## ----claimsDiagSpline, dependson="claimsSplineSum1", fig.env='figure', fig.width=9, fig.height=3, fig.cap="Residual plot (left), histogram (middle) of the raw residuals and qq-plot (right) of the standardized residuals for the additive model with a basis expansion of log insurance sum.", echo=FALSE----
claimsDiag <- fortify(claimsLmSplineAdd) ## Residuals etc.
grid.arrange(
  qplot(.fitted, .resid, data = claimsDiag, alpha = I(0.2)) +
    geom_smooth(),
  qplot(.resid, data = claimsDiag, bins = I(40)),
  qplot(sample = .stdresid, data = claimsDiag, geom = "qq") +
    geom_abline(),
  ncol = 3
)

## ----splinefitPlot, dependson=c("claimsSpline", "claimsScatter"), fig.cap="Scatter plots and fitted values for the claim size models using natural cubic splines including 95\\% pointwise confidence bands. The additive model (blue) gives translations of the same nonlinear relation for all four trade groups wheras the interaction model (red) gives a separate nonlinear relation for all four trade groups.", opts.label='rightwidefigure'----
predAdd <- cbind(claims, exp(predict(claimsLmSplineAdd,
                                 interval = "confidence")))
predInt <- cbind(claims, exp(predict(claimsLmSplineInt,
                                 interval = "confidence")))
p0 + geom_line(aes(y = fit), predAdd, color = "blue", size = 2) +
  geom_ribbon(aes(ymax = upr, ymin = lwr), predAdd,
              fill = "blue", alpha = 0.2) +
  geom_line(aes(y = fit), predInt, color = "red", size = 2) +
  geom_ribbon(aes(ymax = upr, ymin = lwr), predInt,
              fill = "red", alpha = 0.2) +
  facet_wrap(~ grp, ncol = 4)

## ----claimsSplineAnova-----------------------------------------
anova(claimsLmAdd, claimsLmSplineAdd, claimsLmSplineInt)


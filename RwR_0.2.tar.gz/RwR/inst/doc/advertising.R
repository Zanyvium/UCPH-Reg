## ----defaultOptions, echo=FALSE, results="hide", message=FALSE, warning=FALSE, cache=FALSE----
### This chuck sets all the options used by knitr.
library(knitr)
opts_chunk$set(background=c(0.97, 0.97, 0.97), tidy=FALSE, cache=TRUE, dev='pdf', size='footnotesize', fig.align='center', out.width='\\linewidth')
opts_template$set(widefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(rightwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(leftwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(marginfigure = list(fig.height=4, fig.width=4, fig.env='marginfigure'))
opts_template$set(figure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(rightfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(leftfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
options(width = 65, show.signif.stars = FALSE)
hook_output <- knit_hooks$get("output")
knit_hooks$set(output = function(x, options) {
  lines <- options$output.lines
  if (is.null(lines)) {
    hook_output(x, options)  # pass to default hook
  }
  else {
    x <- unlist(stringr::str_split(x, "\n"))
    xx <- character(length(x))
    lines <- seq_along(x)[lines]
    gap <- 0
    j <- k <- 1
    browser()
    for(i in seq_along(x)) {
      if(k <= length(lines) && i == lines[k]) {
        xx[j] <- x[i]
        j <- j + 1
        k <- k + 1
        gap <- 0
      } else if(gap == 0) {
        xx[j] <- "..."
        j <- j + 1
        gap <- 1
      }
    }
    # paste these lines together
    x <- paste(xx[xx != ""], collapse = "\n")
    hook_output(x, options)
  }
})

## ----packages, cache=FALSE, message=FALSE, results="hide", warning=FALSE, echo=FALSE----
library(ggplot2)   ## Grammar of graphics
library(reshape2)  ## Reshaping data frames
library(lattice)   ## More graphics
library(hexbin)    ## and more graphics
library(gridExtra) ## ... and more graphics
library(xtable)    ## LaTeX formatting of tables
library(splines)   ## Splines -- surprise :-)
library(survival)  ## Survival analysis
library(grid)      ## For 'unit'
library(lpSolve)   ## Linear programming

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Adcase/figure/', cache.path='Adcase/cache/')
cor.print <- function(x, y) {
  panel.text(mean(range(x)), mean(range(y)),
             paste('$', round(cor(x, y), digits = 2), '$', sep = '')
             )
}
binScale <- scale_fill_continuous(breaks = c(1, 10, 100, 1000),
                                  low = "gray80", high = "black",
                                  trans = "log", guide = "none")

## ----readingDataAd---------------------------------------------
vegetables <- read.table(
  "http://www.math.ku.dk/~richard/regression/data/vegetablesSale.txt",
  header = TRUE,
  colClasses = c("numeric", "numeric", "factor", "factor",
                 "numeric", "numeric", "numeric")
)
summary(vegetables)

## ----crossTabWeekAd, dependson='readingDataAd', results='asis', echo=FALSE----
print(xtable(table(vegetables[, c("week", "ad")])),
      floating = FALSE
)

## ----dataCorrection, dependson='readingDataAd'-----------------
vegetables <- subset(vegetables, week != 2)
naid <- is.na(vegetables$discount)
impute <- with(subset(vegetables, !is.na(discount) & week == 4),
  c(1, median(discount), median(discountSEK))
               )
vegetables[naid, c("ad", "discount", "discountSEK")] <- impute

vegetables <- within(vegetables, {
    meanNormSale <- sort(tapply(normalSale, store, mean))
    store <- factor(store, levels = names(meanNormSale))
    meanNormSale <- meanNormSale[store]
}
)

## ----densities, dependson='dataCorrection', message=FALSE, warning=FALSE, fig.cap='Density estimates of \\texttt{sale} and \\texttt{normalSale}. Note the log-scale on the $x$-axis.', opts.label='marginfigure', fig.pos='-2cm'----
mVegetables <- melt(vegetables[, c("sale", "normalSale")])
qplot(value, data = mVegetables, geom = "density",
      fill = I(gray(0.5)), xlab = "", ylab = "") +
  scale_x_log10() + facet_wrap(~ variable, ncol = 1)

## ----barplotsII, dependson='dataCorrection', message=FALSE, warning=FALSE, opts.label='widefigure', fig.cap='Barplots of discount variables.', opts.label='marginfigure'----
mVegetables <- melt(vegetables[, c("discount", "discountSEK")])
qplot(value, data = mVegetables, geom = "bar",
      fill = I(gray(0.5)), xlab = "", ylab = "") +
  facet_wrap(~ variable, scales = "free", ncol = 1)

## ----scatterPlotMatrixAd, dependson='dataCorrection', opts.label='leftfigure', fig.cap='Scatter plot matrix of the 4 continuous variables and the corresponding Pearson correlations.'----
contVar <- c("sale", "normalSale", "discount", "discountSEK")
vegLog <- vegetables[, contVar]
vegLog <- transform(vegLog,
                    sale = log10(sale),
                    normalSale = log10(normalSale))
splom(vegLog,
      xlab = "",
      upper.panel = panel.hexbinplot,
      pscales = 0, xbins = 30,
      lower.panel = cor.print
)

## ----catContViolin, dependson='dataCorrection', fig.cap='Violin plots, medians and interdecile ranges for the distribution of \\texttt{normalSale} and \\texttt{discount} stratified according to \\texttt{ad} and \\texttt{week}. A violin plot is a rotated kernel density estimate and can be seen as an alternative to a boxplot.', opts.label='rightfigure', echo=FALSE, warning=FALSE----
deciles <- function(x) {
  quan <- quantile(x, c(0.1, 0.5, 0.9))
  data.frame(ymin = quan[1], y = quan[2], ymax = quan[3])
}
mVegetables <- melt(vegetables[, c("discount", "normalSale", "ad", "week")],
                       id.vars = c("discount", "normalSale"))
p1 <- ggplot(mVegetables, aes(x = value, y = normalSale)) +
  geom_violin(scale = 'width', fill = I(gray(0.8))) +
  scale_y_log10() +
  stat_summary(fun.data = deciles, color = "blue") + xlab("") +
  facet_wrap(~ variable, scale = "free_x")

p2 <- ggplot(mVegetables, aes(x = value, y = discount)) +
  geom_violin(scale = 'width', adjust = 2, fill = I(gray(0.8))) +
  stat_summary(fun.data = deciles, color = "blue") + xlab("") +
  facet_wrap(~ variable, scale = "free_x")
grid.arrange(p1, p2, ncol = 1)

## ----barWeeks, dependson='dataCorrection', fig.cap='Illustration of which stores we have observations from for each of the weeks. The stores are ordered according to the mean normal sale.', fig.height=6, fig.width=4, fig.env='marginfigure', dev='pdf', fig.pos='-6cm'----
ggplot(vegetables, aes(x = store, ymin = week - 0.5,
                       ymax = week + 0.5,
      group = store, color = meanNormSale)) + geom_linerange() +
  coord_flip() + scale_x_discrete(breaks = c()) +
  theme(legend.position = "top") +
  scale_color_continuous("Mean normal sale",
    guide = guide_colorbar(title.position = "top"))

## ----discountPoints, dependson='dataCorrection', fig.cap='Illustration of the relation between the stores and the discount.', fig.height=6, fig.width=4, fig.env='marginfigure', dev='pdf'----
qplot(discount, store, data = vegetables, geom = "point",
      group = store, color = meanNormSale) +
  scale_y_discrete(breaks = c()) + theme(legend.position = "top") +
  scale_color_continuous(guide = "none")

## ----singleTermInclusionAd, dependson='dataCorrection'---------
form <- sale ~ ad + discount + discountSEK + store
nulModel <- glm(sale ~ offset(log(normalSale)),
                family = poisson,
                data = vegetables)
oneTermModels <- add1(nulModel, form, test = "LRT")

## ----singleTermInclusionAdPrint, dependson='singleTermInclusionAd', results='asis', echo=FALSE----
porder <- with(oneTermModels[-1, ], order(get('Pr(>Chi)'), -get('LRT')))
print(xtable(   ## For LaTeX formatting
  oneTermModels[-1, ][porder, -3],
  digits = c(2, 2, 3, 2, 3),
  display = c('s', 'd', 'e', 'f', 'g'),
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----regModelAd1, dependson='dataCorrection', results='hide'----
form <- sale ~ offset(log(normalSale)) + store + ad +
  discount + discountSEK - 1
vegetablesGlm <- glm(form,
                    family = poisson,
                    data = vegetables)

## ----regModelAd1Sum, dependson='regModelAd1', results='asis', echo=FALSE----
print(xtable(
  coef(summary(vegetablesGlm))[-(1:352), ],
      digits = c(2, 2, 2, 2, 2),
      display = c('s', 'f', 'f', 'f', 'g'),
      caption = "Summary table of parameter estimates, standard errors and $t$-tests for the poisson model of sale with 4 predictors. \\label{tab:regModelAd1}"
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='figure/', cache.path='cache/')

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='Adcase/figure/', cache.path='Adcase/cache/')
cor.print <- function(x, y) {
  panel.text(mean(range(x)), mean(range(y)),
             paste('$', round(cor(x, y), digits = 2), '$', sep = '')
  )
}
deciles <- function(x) {
  quan <- quantile(x, c(0.1, 0.5, 0.9))
  data.frame(ymin = quan[1], y = quan[2], ymax = quan[3])
}
binScale <- scale_fill_continuous(breaks = c(1, 10, 100, 1000),
                                  low = "gray80", high = "black",
                                  trans = "log", guide = "none")

## ----modelControlAd, dependson='regModelAd1', results='hide', warning=FALSE, message=FALSE, fig.cap="Diagnostic plots. Deviance residuals, Pearson residuals and the square root of the absolute value of the Pearson residuals plotted against fitted values.", fig.width=9, fig.height=3, fig.env='figure'----
vegetablesDiag <- transform(vegetables,
                            .fitted = predict(vegetablesGlm),
                            .deviance = residuals(vegetablesGlm),
                            .pearson = residuals(vegetablesGlm,
                                                 type = "pearson")
)
p1 <- qplot(.fitted, .deviance, data = vegetablesDiag,
            geom = "hex") + binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("deviance residuals")
p2 <- qplot(.fitted, .pearson, data = vegetablesDiag,
            geom = "hex") + binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("Pearson residuals")
p3 <- qplot(.fitted, sqrt(abs(.pearson)), data = vegetablesDiag,
            geom = "hex") + binScale + geom_smooth(size = 1) +
  xlab("fitted values") +
  ylab("$\\sqrt{|\\text{Pearson residuals}|}$")
grid.arrange(p1, p2, p3, ncol = 3)

## ----regModelAd2, dependson=c('regModelAd1', 'dataCorrection'), results='hide'----
vegetablesGlm2 <- glm(form,
                      family = quasipoisson,
                      data = vegetables)

## ----regModelAd2Sum, dependson='regModelAd2', results='asis', echo=FALSE----
print(xtable(
  coef(summary(vegetablesGlm2))[-(1:352), ],
  digits = c(2, 2, 2, 2, 2),
  display = c('s', 'f', 'f', 'f', 'g')
  ),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----regModelAd3, dependson='dataCorrection', results='hide'----
form <- sale ~ offset(log(normalSale)) + store  + ad +
  ns(discount, knots = c(20, 30, 40), Boundary.knots = c(0, 50)) - 1
vegetablesGlm3 <- glm(form,
                    family = Gamma("log"),
                    data = vegetables)

## ----modelControl3Ad, dependson='regModelAd3', results='hide', warning=FALSE, message=FALSE, fig.cap="Diagnostic plots for the $\\Gamma$-model. Deviance residuals, Pearson residuals and the square root of the absolute value of the Pearson residuals plotted against fitted values.", fig.width=9, fig.height=3, fig.env='leftfigure', echo=FALSE----
vegetablesDiag <- transform(vegetables,
                            .fitted = predict(vegetablesGlm3),
                            .deviance = residuals(vegetablesGlm3),
                            .pearson = residuals(vegetablesGlm3,
                                                 type = "pearson")
)

p1 <- qplot(.fitted, .deviance, data = vegetablesDiag, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("deviance residuals")
p2 <- qplot(.fitted, .pearson, data = vegetablesDiag, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("Pearson residuals")
p3 <- qplot(.fitted, sqrt(abs(.pearson)), data = vegetablesDiag, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("$\\sqrt{|\\text{Pearson residuals}|}$")
grid.arrange(p1, p2, p3, ncol = 3)

## ----regModelAd4, dependson='dataCorrection', results='hide'----
form <- sale ~ offset(log(normalSale)) + store + ad + discount - 1
vegetablesGlm4 <- glm(form,
                    family = Gamma("log"),
                    data = vegetables)
anova(vegetablesGlm4, vegetablesGlm3, test = "LRT")

## ----nonlinearAnovaPrint, dependson='regModelAd4', results='asis', echo=FALSE----
print(xtable(
  anova(vegetablesGlm4, vegetablesGlm3, test = "LRT"),
  digits = c(2, 10, 5, 10, 5, 4),
  display = c('s', 'd', 'g', 'd', 'g', 'g')
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----adModel, dependson='regModelAd3', opts.label='rightwidefigure', fig.cap='Predictions and confidence bands for the sale per normal sale for one typical store (206), and predictions for 7 stores spanning the range of the different stores.'----
predFrame <- expand.grid(
  normalSale = 1,
  store = factor(c(91, 84, 66, 206, 342, 256, 357)),
  ad = factor(c(0, 1)),
  discount = seq(10, 50, 1)
)
predSale <- predict(vegetablesGlm3,
                    newdata = predFrame,
                    se.fit = TRUE)
predFrame <- cbind(predFrame, as.data.frame(predSale))
p1 <- qplot(discount, exp(fit),
            data = subset(predFrame, store == 206), geom = "line") +
  ylab("sale") +   geom_ribbon(aes(ymin = exp(fit - 2 * se.fit),
                                   ymax = exp(fit + 2 * se.fit)),
              alpha = 0.3) + facet_grid(. ~ ad, label = label_both) +
  coord_cartesian(ylim = c(0, 10)) +
  scale_y_continuous(breaks = c(1, 3, 5, 7, 9))
p2 <- qplot(discount, fit, data = predFrame,
            geom = "line", color = store) + ylab("sale") +
  facet_grid(. ~ ad, label = label_both) +
  scale_y_continuous("log-sale")
grid.arrange(p1, p2, ncol = 2)

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='figure/', cache.path='cache/')


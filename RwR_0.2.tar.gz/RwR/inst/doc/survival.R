## ----defaultOptions, echo=FALSE, results="hide", message=FALSE, warning=FALSE, cache=FALSE----
### This chuck sets all the options used by knitr.
library(knitr)
opts_chunk$set(background=c(0.97, 0.97, 0.97), tidy=FALSE, cache=TRUE, dev='pdf', size='footnotesize', fig.align='center', out.width='\\linewidth')
opts_template$set(widefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(rightwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(leftwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(marginfigure = list(fig.height=4, fig.width=4, fig.env='marginfigure'))
opts_template$set(figure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(rightfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(leftfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
options(width = 65, show.signif.stars = FALSE)
hook_output <- knit_hooks$get("output")
knit_hooks$set(output = function(x, options) {
  lines <- options$output.lines
  if (is.null(lines)) {
    hook_output(x, options)  # pass to default hook
  }
  else {
    x <- unlist(stringr::str_split(x, "\n"))
    xx <- character(length(x))
    lines <- seq_along(x)[lines]
    gap <- 0
    j <- k <- 1
    browser()
    for(i in seq_along(x)) {
      if(k <= length(lines) && i == lines[k]) {
        xx[j] <- x[i]
        j <- j + 1
        k <- k + 1
        gap <- 0
      } else if(gap == 0) {
        xx[j] <- "..."
        j <- j + 1
        gap <- 1
      }
    }
    # paste these lines together
    x <- paste(xx[xx != ""], collapse = "\n")
    hook_output(x, options)
  }
})

## ----packages, cache=FALSE, message=FALSE, results="hide", warning=FALSE, echo=FALSE----
library(ggplot2)   ## Grammar of graphics
library(reshape2)  ## Reshaping data frames
library(lattice)   ## More graphics
library(hexbin)    ## and more graphics
library(gridExtra) ## ... and more graphics
library(xtable)    ## LaTeX formatting of tables
library(splines)   ## Splines -- surprise :-)
library(survival)  ## Survival analysis
library(grid)      ## For 'unit'
library(lpSolve)   ## Linear programming

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='SurvCase/figure/', cache.path='SurvCase/cache/')

## ----survReadingData-------------------------------------------
prostate <- read.table("prostate.txt",
                       header = TRUE,
                       colClasses =
                         c("factor", "factor", "factor", "numeric",
                           "factor", "numeric", "numeric", "factor",
                           "factor", "numeric", "numeric", "factor",
                           "numeric", "numeric", "numeric", "numeric",
                           "factor", "character")
)

## ----survVariables, dependson="survReadingData"----------------
names(prostate)
## For later usage
conVar <- c("dtime", "age", "wt", "sbp", "dbp","hg", "sz", "sg", "ap")
disVar <- c( "stage", "rx", "status", "pf", "hx", "ekg", "bm")

## ----survHistograms, dependson="survVariables", message=FALSE, warning=FALSE, fig.cap="Histograms for continuous predictor variables.", fig.width=12, fig.height=5, fig.env='figure*'----
meltedProstate <- melt(prostate[, conVar])
qplot(value, data = meltedProstate, geom = "histogram",
      xlab = "", ylab = "") +
  facet_wrap(~ variable, scales = "free", ncol = 5)

## ----survBarplots, dependson="survVariables", message=FALSE, warning=FALSE, fig.cap="Barplots for categorical predictor variables.", fig.width=12, fig.height=5, fig.env='leftwidefigure'----
meltedProstate <- melt(prostate[, disVar], id.vars = c())
qplot(value, data = meltedProstate, geom = "bar",
      xlab = "", ylab = "") +
  facet_wrap(~ variable, scales = "free", ncol = 4) +
  theme(axis.text.x = element_text(angle = -30,
         size = 8, hjust = 0, vjust = 1))

## ----survScatterPlotMatrix, dependson="survVariables", fig.cap="Scatter plot matrix and Pearson correlations for the continuous variables.", fig.height=6, fig.width=6, fig.env='rightfigure', out.width='.9\\linewidth', fig.pos='t'----
  splom(na.omit(prostate[, conVar]),
        upper.panel = panel.hexbinplot,
        pscale = 0,
        varname.cex = 0.7,
        nbins = 15,
        lower.panel = function(x, y) {
          panel.text(mean(range(x)), mean(range(y)),
                     round(cor(x, y), digits = 2),
                     cex = 0.7
                     )
        }
        )

## ----survMargReg, dependson="survVariables", warning=FALSE, message=FALSE----
### The number of missing values for each variable.

sapply(prostate, function(x) sum(is.na(x)))

### Dropping observations with missing variables,
### and other data cleaning / manipulations.

subProstate <-
  transform(na.omit(prostate),
            bp = (sbp + dbp) / 2,     ## Average blood presure.
            logap = log(ap)
  )
conVar <- c(conVar, "logap", "bp")

## ----surv1, dependson="survMargReg", fig.cap="Kaplan-Meier estimators of the survival functions within each of the four treatment groups.", opts.label="marginfigure", fig.pos="-4cm"----
prostateSurv <- survfit(Surv(dtime, status != "alive") ~ rx,
                        data = subProstate)
plot(prostateSurv, mark.time = FALSE, conf.int = FALSE,
     col = c("red", "blue", "purple", "cyan"))
legend(30, 1.08, levels(subProstate$rx),
       col = c("red", "blue", "purple", "cyan"),
       lty = 1, bty = "n")

## ----FirstCoxModel, dependson="survMargReg", results='hide'----
form <- Surv(dtime, status != "alive") ~ rx + age + wt + pf +
  hx + ekg + hg + sz + sg + logap + bp + bm
prostateCox <- coxph(form, data = subProstate)
testtab <- drop1(prostateCox, test = "Chisq")
ord <- order(testtab[, 4][-1]) + 1
testtab[ord, ]

## ----FirstCoxModelprint, dependson="FirstCoxModel", results='asis', echo=FALSE----
print(xtable(testtab[ord, -2]),
      floating = FALSE,
      math.style.negative = TRUE)

## ----baseline, dependson="FirstCoxModel", fig.cap="The nonparametric estimate of the baseline survival function.", opts.label="marginfigure"----
w <- predict(prostateCox, type = "risk")  ## Individual weights
orddtime <- order(subProstate$dtime)
stat <- (subProstate$status != "alive")[orddtime]
W <- rev(cumsum(w[rev(orddtime)]))
Lambda <- cumsum(stat / W)
qplot(subProstate$dtime[orddtime], exp(-Lambda), geom = "step") +
  ylab("Survival function") + xlab("time (months)") + ylim(c(0,1))

## ----baselineSurvfit, dependson="FirstCoxModel", fig.cap="The \\texttt{plot} method for a \\texttt{survfit} object plots the nonparametric estimate of the baseline survival function including a pointwise 95\\% confidence band.", opts.label="marginfigure"----
plot(survfit(prostateCox), mark.time = FALSE)

## ----CoxSnell, dependson="baseline", fig.cap="Cox-Snell residual plot.", opts.label="marginfigure", fig.pos="-1cm"----
CSres <- Lambda * w[orddtime] ## Cox-Snell residuals
ordres <- order(CSres)
CSres <- CSres[ordres]
statres <- stat[ordres] ## Indicator of non-censoring
## Computation of cumulative hazards using 'survfit'.
tmp <- survfit(Surv(CSres, statres) ~ 1, type = "fleming-harrington")
CumHaz <- -log(tmp$surv)[statres]
## Alternative direct computation of cumulative hazards
## Y <- seq(length(Lambda), 1)[statres]
## CumHaz <- cumsum(1/Y)
## Nelson-Aalen estimator of exponential cumulative hazard
qplot(CSres[statres], CumHaz) +
  geom_abline(intercept = 0, slope = 1) +
  geom_point(color = "red") +
  ylab("Cum. Hazards") + xlab("Cox-Snell residuals")

## ----survResidualPlots, dependson="FirstCoxModel", message=FALSE, fig.cap="Martingale residuals plotted against predictor variables. The residuals have a skewed distribution but zero mean if the model is correct. The smoothed line can assist in the detection of variables with nonlinear effects.", fig.width=12, fig.height=5, fig.env='rightwidefigure'----
prostateData <- subProstate[, c("patno", all.vars(form)[-c(1, 2)])]
## Change the 'type' argument below to 'deviance' for deviance residuals
predProstate <-
  cbind(prostateData,
        data.frame(mgres = residuals(prostateCox,
                                     type = 'martingale'))
  )

meltedPredProstate <-
  melt(predProstate,
       id.vars = c("patno", "mgres"),
       measure.vars = conVar[conVar %in% all.vars(form)[-c(1, 2)]])

qplot(value, mgres, data = meltedPredProstate,
      xlab = "", ylab = "", geom = "point",
      alpha = I(0.3), size = I(3)) +
  facet_wrap(~ variable, scales = "free_x", ncol = 4) +
  geom_smooth(size = 1, fill = "blue")

## ----survSecondModel, dependson="survMargReg", results='hide'----
form <- Surv(dtime, status != "alive") ~ rx + ns(age, 4) + ns(wt, 4) +
  + pf + hx + ekg +  ns(hg, 4) + ns(sz, 4) +
  ns(sg, 4) + ns(logap, 4) + ns(bp, 4) + bm
prostateCox2 <- coxph(form, data = subProstate)
drop1(prostateCox2, test = "Chisq")[ord, ]
anova(prostateCox2, prostateCox)

## ----survTest, dependson=c("survSecondModel", "FirstCoxModel"), results='asis', echo=FALSE----
print(xtable(anova(prostateCox2, prostateCox)[2, ]), include.rownames = FALSE,
      floating = FALSE,
      math.style.negative = TRUE)

## ----survSecondModelprint, dependson="survSecondModel", results='asis', echo=FALSE----
print(xtable(drop1(prostateCox2, test = "Chisq")[ord, -2]),
      floating = FALSE,
      math.style.negative = TRUE
      )

## ----coxph0, dependson="survMargReg", results='hide'-----------
prostateCox0 <- coxph(Surv(dtime, status != "alive") ~ rx,
                      data = subProstate)
summary(prostateCox0)

## ----cosph0print, dependson="coxph0", results='asis', echo=FALSE----
print(xtable(coef(summary(prostateCox0))),
      floating = FALSE,
      math.style.negative = TRUE)

## ----propHazardCheck0, dependson="coxph0", fig.cap="Diagnostic plot for checking the proportional hazards assumption for the treatment without other predictors.", opts.label="marginfigure", fig.pos="-3cm"----
## The cloglog transform gives the log cumulative hazards plotted
## against the log times
plot(prostateSurv, mark.time = FALSE, conf.int = FALSE,
     col = c("red", "blue", "purple", "cyan"),
     fun = "cloglog")

## ----propHazardCheck01, dependson="FirstCoxModel", fig.cap="Diagnostic plot for checking the proportional hazards assumption for the treatment with the other predictors included.", opts.label="marginfigure"----
prostateCox2a <- update(prostateCox2, . ~ . - rx)
w <- predict(prostateCox2a, type = "risk")  ## Individual weights
orddtime <- order(subProstate$dtime)
stat <- (subProstate$status != "alive")[orddtime]
rxord <- subProstate$rx[orddtime]
W <- tapply(w[orddtime], rxord, function(ww) rev(cumsum(rev(ww))))
statstrat <- tapply(stat, rxord, function(x) x)
tmp <- list()
for(i in 1:4) {
  tmp[[i]] <- data.frame(
    logLambda = log(cumsum(statstrat[[i]] / W[[i]])),
    time = subProstate$dtime[orddtime][as.numeric(rxord) == i],
    rx = names(statstrat)[i]
  )
}

tmp <- do.call(rbind, tmp)
ggplot(tmp, aes(time, logLambda, color = rx)) +
  geom_line() +
  scale_color_manual("",
                     values = c("red", "blue", "purple", "cyan")) +
  scale_x_log10(breaks = c(1, 2, 5, 10, 20, 50)) +
  xlab("log time") + ylab("log cum. hazards") +
  theme(legend.position = c(1, 0),
        legend.justification = c(1, 0))

## ----survTermplot, dependson="survSecondModel", fig.cap="Estimates and 95\\% confidence bands for the nonlinear effects of the  continuous variables.", fig.width=12, fig.height=5, fig.env='figure*'----
predictProstate <- predict(prostateCox2, type = "terms", se.fit = TRUE)
predictData <- melt(subProstate[, c("patno", conVar[-c(1, 4, 5, 9)])],
                    id.vars = "patno")

selectedTerms <- which(all.vars(form)[- c(1, 2)] %in% conVar)

plotData <-
  cbind(predictData,
        se = melt(predictProstate$se.fit[, selectedTerms])$value,
        y = melt(predictProstate$fit[, selectedTerms])$value
  )

ggplot(plotData, aes(x = value), xlab = "", ylab = "") +
  geom_ribbon(aes(ymin = y - 2*se, ymax = y + 2*se),
              alpha = I(0.2),
              fill = I("blue")) +
  geom_line(aes(y = y), size = 1) +
  facet_wrap(~ variable, ncol = 4, scale = "free") +
  ylab("") + xlab("Variable values")

## ----survTermplot2, dependson="survSecondModel", fig.cap="Estimates and 95\\% confidence intervals of the parameters related to the factor variables.", fig.width=12, fig.height=4, fig.env='figure*'----
plotData <- cbind(
  as.data.frame(confint(prostateCox2, c(1:3, 12:21, 42))),
  coef(prostateCox2)[ c(1:3, 12:21, 42)])
names(plotData) <- c("low", "up", "hat")
plotData$variable <-
  c(rep("rx", 3), rep("pf", 3), "hx", rep("ekg", 6), "bm")
plotData$value <- rownames(plotData)

ggplot(plotData, aes(x = value, xlab = "", ylab = "")) +
  geom_errorbar(aes(ymin = low, ymax = up),
                colour = I("blue")) +
  geom_point(aes(y = hat), size = 3) +
  facet_grid(.~ variable, scales = "free_x", space = "free_x") +
  theme(axis.text.x = element_text(angle = -30,
         size = 8, hjust = 0, vjust = 1)) +
  ylab("$\\hat{\\beta}$") + xlab("Variable values")

